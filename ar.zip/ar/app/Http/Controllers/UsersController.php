<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Config;
use ApiChef\Obfuscate\Support\Facades\Obfuscate;

use App\Models\Core\Setting;
use App\Models\Admin\Admin;
use App\Models\Core\Order;
use App\Models\Core\Customers;
use App\Models\Core\Drivers;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Lang;
use Illuminate\Support\Facades\Input;
use Exception;
use App\Models\Core\Images;
use Validator;
use Hash;
use Auth;
use ZipArchive;
use File;
use Carbon\Carbon;



class UsersController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    /****** View  Roles Start ******/

        public function manageUsers(){
			$manageusers = DB::table('users')->select('users.*','user_types.*','users.id as userID')
                ->Join('user_types', 'user_types.id', '=', 'users.user_types_id')
                ->orderBy('users.id','Asc')->get();

                $manageteaching = DB::table('users')->select('users.*','user_types.*','users.id as userID')
                ->Join('user_types', 'user_types.id', '=', 'users.user_types_id')->where('users.user_types_id','4')
                ->orderBy('users.id','Asc')->get();

                $managenonteaching = DB::table('users')->select('users.*','user_types.*','users.id as userID')
                ->Join('user_types', 'user_types.id', '=', 'users.user_types_id')->where('users.user_types_id','5')
                ->orderBy('users.id','Asc')->get();

                $userrole = DB::table('user_types')->where('status','Active')->get();

            return view("users.index")->with('manageusers',$manageusers)->with('userrole',$userrole)->with('manageteaching',$manageteaching)
            ->with('managenonteaching',$managenonteaching);
           
        }
                  
        public function manageEdits($id){
            $managenonteaching = DB::table('users')->select('users.*','user_types.*','users.id as userID')
            ->Join('user_types', 'user_types.id', '=', 'users.user_types_id')
            ->where('users.id', '=', $id)
            ->first();
	        $department = DB::table('department')->orderBy('id','Asc')->get();

            return view("users.edit")->with('managenonteaching',$managenonteaching)->with('department',$department);
            
        }


    public function manageStudents(){
            $manageStudents = DB::table('students')->orderBy('id','Asc')->get();
            return view("students.index")->with('managestudents', $manageStudents);
       }
    
    /******   View Roles  end ******/

    public function usersAttendance($id){
            $attendance = DB::table('attendances')->select('attendances.*','users.*','attendances.id as userID')
                ->Join('users', 'users.id', '=', 'attendances.user_id')
                ->orderBy('attendances.id','Asc')->get();
            return view("users.attendance")->with('attendance', $attendance);
        }

    /****** Add  Roles Action Start ******/

        public function addUser(Request $request){
               /* $email = trim($request->get('email'));
                $emailcheck = DB::table('users')->select('email')->where('email','=',$email)->get();

               if(count($emailcheck) > 0){
            return redirect('/users')->with('error', 'Email already used by another user');
        }else{*/
            $customers_id = DB::table('users')->insertGetId([
               
              
                'first_name'		 		=>   $request->first_name.' '.$request->last_name,
                'last_name'			 		=>   $request->last_name,
                'father_name'			 	=>   $request->father_name,
                'mobile'	 		     	=>	 $request->mobile,
                'email'                     =>   $request->email,
                'date_of_birth'             =>   $request->date_of_birth,
                'age'                       =>   $request->age,
                'place_of_birth'            =>   $request->place_of_birth,
                'adhaar'                    =>   $request->adhaar,
                'blood_group'               =>   $request->blood_group,
                'language_known'            =>   $request->language_known,
                'hobbies'                   =>   $request->hobbies,
                'pan_no'                    =>   $request->pan_no,
                'pin_code'                  =>   $request->pin_code,
                'comunity'                  =>   $request->comunity,
                'religion'                  =>   $request->religion,
                'nationalty'                =>   $request->nationalty,
                'mother_tongue'             =>   $request->mother_tongue,
                'whats_up'                  =>   $request->whats_up,
                'password'		 			=>   Hash::make($request->password),
                'check_password'		 	=>   $request->password,
                'gender'                    =>   $request->gender,
                'address'                   =>   $request->address,
                'created_at'                =>   date('Y-m-d H:i:s'),
                'user_types_id'			    =>	 $request->user_types_id
                ]);

                
                $last_insert_id = DB::getPdo()->lastInsertId();
               $profile_photo ="";
                if($request->profile_photo != null){
                    $photo =  $last_insert_id.'.'.$request->file('profile_photo')->extension(); 
                    $filepath = public_path('uploads'.DIRECTORY_SEPARATOR.'photo'.DIRECTORY_SEPARATOR);
                    move_uploaded_file($_FILES['photo']['tmp_name'], $filepath.$photo);
                }

                $customers_id = DB::table('users')->where('id',$last_insert_id)->update([
                    'profile_photo'             =>  $request->profile_photo,
                ]);   
                
         $addUserRoles = DB::table('user_permission')->insert([
                'user_types_id'   =>   $request->user_types_id,
                'user_id'         =>   $customers_id,
                ]);
                return redirect('/users')->with('success', 'Users Created Successfully');
        }

    
 
     /****** Edit  Roles Start ******/

public function editUser(Request $request){
   
             $edituser = DB::table('users')->where('id',$request->id)->update([
           
                'first_name'		 		=>   $request->first_name,
                'last_name'			 		=>   $request->last_name,
                'father_name'			 	=>   $request->father_name,
                'mobile'	 		     	=>	 $request->mobile,
                'email'                     =>   $request->email,
                'date_of_birth'             =>   $request->date_of_birth,
                'age'                       =>   $request->age,
                'place_of_birth'            =>   $request->place_of_birth,
                'adhaar'                    =>   $request->adhaar,
                'blood_group'               =>   $request->blood_group,
                'language_known'            =>   $request->language_known,
                'hobbies'                   =>   $request->hobbies,
                'pan_no'                    =>   $request->pan_no,
                'pin_code'                  =>   $request->pin_code,
                'comunity'                  =>   $request->comunity,
                'religion'                  =>   $request->religion,
                'nationalty'                =>   $request->nationalty,
                'mother_tongue'             =>   $request->mother_tongue,
                'whats_up'                  =>   $request->whats_up,
                'password'		 			=>   Hash::make($request->password),
                'check_password'		 	=>   $request->password,
                'gender'                    =>   $request->gender,
                'address'                   =>   $request->address,
                'updated_at'                =>   date('Y-m-d H:i:s'),
                
                ]);
                           // Print_r($edituser);die();

                return redirect('/users')->with('success', 'Users Updated Successfully'); 
            }


            public function editStudents(Request $request){
   
                $edituser = DB::table('students')->where('id',$request->id)->update([
            
                    'first_name'              =>   $request->first_name,
                    'last_name'               =>   $request->last_name,
                    'father_name'             =>   $request->father_name,
                    'mother_name'             =>   $request->mother_name,
                    'department'              =>   $request->department,
                    'date_of_birth'           =>   $request->date_of_birth,
                    'age'                     =>   $request->age,
                    'gender'                  =>   $request->gender,
                    'adhar'                   =>   $request->adhar,
                    'father_job'              =>   $request->father_job,
                    'religion'                =>   $request->religion,
                    'mobile'                  =>   $request->mobile,
                    'address'                 =>   $request->address,
                    'pin_code'                 =>   $request->pincode,
                    'email'                   =>   $request->email,
                    'status'                  =>   $request->status,
                    'updated_at'              =>   date('Y-m-d H:i:s'),
                ]);
            
                return redirect('/students')->with('success', 'Updated Successfully'); 
            }
            
/******   Edit Users End ******/

public function checkemail(Request $request){
    $email = trim($request->get('email'));
    $id = trim($request->get('id'));
    if($id == 0){
        $sql = "SELECT * FROM users where email='$email'";
    }else{
        $sql = "SELECT * FROM users where email='$email' and id <> $id";
    }
    $emailcheck = DB::select(DB::raw($sql));
    if(count($emailcheck) > 0){
        return response()->json(array("exists" => true));
    }else{
        return response()->json(array("exists" => false));   
    }
}

}
